function initialise()
{
	setupAjax();
}
function setupAjax()
{
	// Refresh the lecturer list when it is clicked
	var menu = document.getElementById("menu");
	var menuItems=menu.getElementsByTagName("li");

	menuItems[0].onclick=function() {requestData("toptracks.json",loadtoptracks); };
	menuItems[1].onclick=function() {requestData("topartists.json",loadtopartists); };
	menuItems[2].onclick=function()	{requestData("events.xml",loadevents); };
	
	var link=document.getElementsByClassName("linkContent");
	
	link[0].onclick=function() {requestData("toptracks.json",loadtoptracks); };
	link[1].onclick=function() {requestData("topartists.json",loadtopartists); };
	link[2].onclick=function() {requestData("events.xml",loadevents); };
	
}
function hideContents()
{
	var contents=document.getElementsByClassName("content");
	for(var i=0;i<contents.length;i++)
	{
		contents[i].style.display="none";
	}
	var table=document.getElementById("page").style.display="block";
}
function showContents()
{
	var contents=document.getElementsByClassName("content");
	for(var i=0;i<contents.length;i++)
	{
		contents[i].style.display="block";
	}
	var table=document.getElementById("page").style.display="none";
}
// Global array to store item info
var items = [];
// Load the items data and put it in the table
function loadtoptracks(xmlhttp)
{
	items=[];
	hideContents();
	// Extract the list of items from JSON
	var jsonDoc = JSON.parse(xmlhttp.responseText);
	
	var jsonTracks = jsonDoc.tracks.track;
	//console.log(jsonTracks);
	
	// Loop through the items
	for (var i = 0; i < jsonTracks.length; i++) {
	
		//Extract basic info about each item
		var trackArtistName = jsonTracks[i].artist.namework;
		var trackArtistURL=jsonTracks[i].artist.url;
		var trackTitle = jsonTracks[i].namework;
		var trackTitleURL=jsonTracks[i].url;
		var trackListeners = jsonTracks[i].listeners;
		var trackPlayCount = parseInt(jsonTracks[i].playcount);
		
		// Create an object to store info about the item
		var track = {
			artist : trackArtistName,
			artisturl:trackArtistURL,
			title : trackTitle,
			songurl: trackTitleURL,
			listeners : trackListeners,
			playcount : trackPlayCount,
		};
		
		// And add to the (global)list of items
		items.push(track);
	}
	
	// Refresh the table
	fillTableTopTracks();
}

// Refresh the items table using the info in the 'items' array
function fillTableTopTracks()
{
	// Get the (existing) table
	var table = document.getElementById("page");
	
	// Clear any existing contents
	while (table.childNodes.length > 0) {
		table.removeChild(table.firstChild);
	}
	
	// Add a row for each item
	for (var i = 0; i < items.length; i++) {
		// New row
		var tr = document.createElement("tr");
		
		// Left hand cell, containing image
		var td1 = document.createElement("td");
		//var img = document.createElement("img");
		//img.setAttribute("src", items[i].imgUrl);
		//td1.appendChild(img);
		
		// Right hand cell, containing item details
		var td2 = document.createElement("td");
		
		// Title
		var divTitle = document.createElement("div");
		divTitle.id="divSong";
		var linkSong = document.createElement("a");
		linkSong.setAttribute("href", items[i].songurl);
		linkSong.innerHTML = items[i].title;
		divTitle.appendChild(linkSong);
		td1.appendChild(divTitle);

		// Artist
		var divArtist = document.createElement("div");
		divArtist.id="divArtist";
		var linkArtist = document.createElement("a");
		linkArtist.setAttribute("href", items[i].artisturl);
		divArtist.innerHTML = "Artist: "+items[i].artist;
		divArtist.appendChild(linkArtist);
		td1.appendChild(divArtist);

		//Listeners
		var divListeners = document.createElement("div");
		divListeners.id="divListeners";
		divListeners.innerHTML = "Listeners: "+items[i].listeners;
		td1.appendChild(divListeners);

		//PlayCount
		var divPlayCount = document.createElement("div");
		divPlayCount.id="divPlays";
		divPlayCount.innerHTML = "Playcount: "+items[i].playcount;
		td2.appendChild(divPlayCount);

		tr.appendChild(td1);
		tr.appendChild(td2);
		table.appendChild(tr);
		
	}
}
function loadtopartists(xmlhttp)
{
	items=[];
	hideContents();
	// Extract the list of items from JSON
	var jsonDoc = JSON.parse(xmlhttp.responseText);
	
	var jsonArtists = jsonDoc.artists.artist;
	//console.log(jsonTracks);
	
	// Loop through the items
	for (var i = 0; i < jsonArtists.length; i++) {
	
		//Extract basic info about each item
		var ArtistName = jsonArtists[i].namework;
		var ArtistImage=jsonArtists[i].image[3].url;
		var ArtistListeners = jsonArtists[i].listeners;
		var ArtistURL=jsonArtists[i].url;
		var ArtistPlayCount = parseInt(jsonArtists[i].playcount);
		
		// Create an object to store info about the item
		var artist = {
			artist : ArtistName,
			artisturl:ArtistURL,
			image : ArtistImage,
			listeners : ArtistListeners,
			playcount : ArtistPlayCount,
		};
		
		// And add to the (global)list of items
		items.push(artist);
	}
	
	// Refresh the table
	fillTableTopArtists();
}

// Refresh the items table using the info in the 'items' array
function fillTableTopArtists()
{
	// Get the (existing) table
	var table = document.getElementById("page");
	
	// Clear any existing contents
	while (table.childNodes.length > 0) {
		table.removeChild(table.firstChild);
	}
	
	// Add a row for each item
	for (var i = 0; i < items.length; i++) {
		// New row
		var tr = document.createElement("tr");
		
		// Left hand cell, containing image
		var td1 = document.createElement("td");
		var img = document.createElement("img");
		img.setAttribute("src", items[i].image);
		td1.appendChild(img);
		
		// Right hand cell, containing item details
		var td2 = document.createElement("td");
		
		// Title
		var divTitle = document.createElement("div");
		divTitle.id="divArtist";
		var linkArtist = document.createElement("a");
		linkArtist.setAttribute("href", items[i].artisturl);
		linkArtist.innerHTML = items[i].artist;
		divTitle.appendChild(linkArtist);
		td2.appendChild(divTitle);

		//Listeners
		var divListeners = document.createElement("div");
		divListeners.id="divListeners";
		divListeners.innerHTML = "Listeners: "+items[i].listeners;
		td1.appendChild(divListeners);

		//PlayCount
		var divPlayCount = document.createElement("div");
		divPlayCount.id="divPlays";
		divPlayCount.innerHTML = "Playcount: "+items[i].playcount;
		td1.appendChild(divPlayCount);

		tr.appendChild(td1);
		tr.appendChild(td2);
		table.appendChild(tr);
		
	}
}
function requestData(url, callBack)
{
	// Create a new XMLHttpRequest object
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4) {
			callBack(xmlhttp);
		}
	}
	// Open the object with the filename
	xmlhttp.open("POST", url, true);
	// Send the request
	xmlhttp.send(null);
}
function loadevents(xmlhttp)
{
	items=[];
	var table = document.getElementById("page");
	hideContents();
	// Clear any existing contents
	while (table.childNodes.length > 0) {
		table.removeChild(table.firstChild);
	}
	var xmldoc = xmlhttp.responseXML;
	var events = xmldoc.getElementsByTagName("event");
	for (var i = 0; i < events.length; i++)
	{
		//Extract basic info about each item
		var EventArtists = events[i].getElementsByTagName("artist");
		var EventDate=events[i].getElementsByTagName("startDate")[0];
		var EventTags = events[i].getElementsByTagName("tag");
		var EventURL=events[i].getElementsByTagName("url")[1];
		// Add a row for each item
		var tr = document.createElement("tr");

		var td1 = document.createElement("td");
		// Right hand cell, containing item details
		var td2 = document.createElement("td");
		
		// Title
		var divArtists = document.createElement("div");
		divArtists.id="divArtist";
		divArtists.innerHTML = "The artists for this event are: ";
		for(var j=0;j<EventArtists.length;j++)
		{	
			if(j==0)
				divArtists.innerHTML += "<b> <big>"+EventArtists[j].firstChild.data + "</b></big>; ";
			else if (j==EventArtists.length-1)
				divArtists.innerHTML += EventArtists[j].firstChild.data;
			else
				divArtists.innerHTML += EventArtists[j].firstChild.data + "; ";
		}
		td1.appendChild(divArtists);

		//URL
		var divLink = document.createElement("div");
		divLink.id="divURL";
		var linkEvent = document.createElement("a");
		linkEvent.setAttribute("href", EventURL.firstChild.data);
		linkEvent.innerHTML = "Click here for redirecting to the event page";
		divLink.appendChild(linkEvent);
		td2.appendChild(divLink);
		
		//Date
		var divDate = document.createElement("div");
		divDate.id="divDate";
		divDate.innerHTML = "The date for this event is: "+EventDate.firstChild.data;
		td1.appendChild(divDate);

		//Tags
		var divTags = document.createElement("div");
		divTags.id="divTag";
		divTags.innerHTML = "<b>Tags</b>: ";
		var divTag = document.createElement("div");
		for(var j=1;j<EventTags.length;j++)
		{
			divTags.innerHTML += "<br> </br>" + EventTags[j].firstChild.data;
		}
		td1.appendChild(divTags);

		tr.appendChild(td1);
		tr.appendChild(td2);
		table.appendChild(tr);	
	}
}
